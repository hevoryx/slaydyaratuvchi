# AI Slayd Yaratuvchi

Personal AI presentation generator (React + Vite frontend, small Node backend).
The Gemini API key lives **only on the backend**; the browser never sees it.

## Setup
1. `npm install`
2. `cp .env.example .env.local` and set `GEMINI_API_KEY` (https://aistudio.google.com/app/apikey)
3. Development: `npm run dev:all` (backend :3001 + Vite :3000) → open http://127.0.0.1:3000
   Production: `npm start` (builds, then serves everything on :3001)
4. Backend tests: `npm test`

## Layout
- `server/` – API proxy (validation, timeouts, retries, rate-limit/provider error mapping, duplicate-request guard), prompts
- `services/geminiService.ts` – thin browser client for `/api/*`
- `utils/pptxGenerator.ts`, `components/`, `utils/themes.ts` – unchanged this phase

## Status
See the delivery notes in the chat for what is done, tested, and still open.
