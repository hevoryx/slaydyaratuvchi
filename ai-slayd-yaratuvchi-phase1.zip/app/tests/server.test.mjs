import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
delete process.env.GEMINI_API_KEY;
const { server } = await import('../server/index.mjs');
let base;
before(() => new Promise((r) => server.listen(0, '127.0.0.1', () => { base = `http://127.0.0.1:${server.address().port}`; r(); })));
after(() => server.close());
const post = (p, body, headers = { 'Content-Type': 'application/json' }) =>
  fetch(base + p, { method: 'POST', headers, body: typeof body === 'string' ? body : JSON.stringify(body) });
const ok = { topic: 'Solar system', slideCount: 10, planCount: 5, language: 'en' };

test('status reports unconfigured key and never leaks it', async () => {
  const j = await (await fetch(base + '/api/status')).json();
  assert.equal(j.gemini.configured, false);
  assert.ok(!JSON.stringify(j).includes('AIza'));
});
test('valid request without key -> 503 NO_API_KEY with setup hint', async () => {
  const r = await post('/api/plan', ok); const j = await r.json();
  assert.equal(r.status, 503); assert.equal(j.error.code, 'NO_API_KEY'); assert.match(j.error.message, /\.env\.example/);
});
test('rejects bad language, counts, missing/oversized topic', async () => {
  for (const bad of [{ ...ok, language: 'xx' }, { ...ok, slideCount: 0 }, { ...ok, slideCount: 999 }, { ...ok, planCount: 1.5 }, { ...ok, topic: '' }, { ...ok, topic: 'a'.repeat(301) }, { ...ok, additionalInfo: 5 }]) {
    const r = await post('/api/plan', bad); assert.equal(r.status, 400, JSON.stringify(bad).slice(0, 60)); assert.equal((await r.json()).error.code, 'BAD_INPUT');
  }
});
test('image endpoint validates prompt', async () => {
  assert.equal((await post('/api/image', {})).status, 400);
  assert.equal((await post('/api/image', { prompt: 'x'.repeat(601) })).status, 400);
  assert.equal((await post('/api/image', { prompt: 'a tree' })).status, 503);
});
test('malformed JSON, wrong content-type, wrong method, unknown route', async () => {
  assert.equal((await post('/api/plan', '{oops')).status, 400);
  assert.equal((await post('/api/plan', 'x', { 'Content-Type': 'text/plain' })).status, 415);
  assert.equal((await fetch(base + '/api/plan')).status, 405);
  assert.equal((await post('/api/nope', {})).status, 404);
});
test('oversized body rejected', async () => {
  const r = await post('/api/plan', JSON.stringify({ topic: 'a'.repeat(200000) }));
  assert.equal(r.status, 413);
});
