import { Slide } from "../types";

// The browser never sees an API key: all AI calls go to our own backend (/api/*).

export class ApiClientError extends Error {
  constructor(public code: string, message: string) { super(message); this.name = 'ApiClientError'; }
}

async function post<T>(path: string, body: unknown, signal?: AbortSignal): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal });
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw new ApiClientError('CANCELLED', 'Request cancelled.');
    throw new ApiClientError('SERVER_UNREACHABLE', 'Cannot reach the backend. Start it with "npm run server" (or "npm run dev:all").');
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new ApiClientError(data?.error?.code ?? 'HTTP_' + res.status, data?.error?.message ?? `Server error (${res.status}).`);
  return data as T;
}

export interface ProviderStatus { gemini: { configured: boolean; textModel: string; imageModel: string } }

export const getProviderStatus = async (): Promise<ProviderStatus | null> => {
  try { const r = await fetch('/api/status'); return r.ok ? await r.json() : null; } catch { return null; }
};

export const generatePresentationPlan = (
  topic: string, slideCount: number, planCount: number, language: string, additionalInfo?: string, signal?: AbortSignal
) => post<{ themeId: string; slides: Slide[]; backgroundVisualPrompt: string }>(
  '/api/plan', { topic, slideCount, planCount, language, additionalInfo }, signal);

/** Throws ApiClientError with a readable message when generation fails (no silent failures). */
export const generateSlideImage = async (prompt: string, isBackground = false, signal?: AbortSignal): Promise<string> =>
  (await post<{ imageData: string }>('/api/image', { prompt, isBackground }, signal)).imageData;
