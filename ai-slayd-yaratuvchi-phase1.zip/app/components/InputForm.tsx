
import React, { useState } from 'react';
import { Sparkles, ArrowRight, ListOrdered, Globe, Layers, FileText } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface InputFormProps {
  onGenerate: (topic: string, slideCount: number, planCount: number, language: Language, description?: string) => void;
  isProcessing: boolean;
  onLanguageChange: (lang: Language) => void;
  currentLang: Language;
}

export const InputForm: React.FC<InputFormProps> = ({ onGenerate, isProcessing, onLanguageChange, currentLang }) => {
  const [topic, setTopic] = useState('');
  const [description, setDescription] = useState('');
  const [slideCount, setSlideCount] = useState(10);
  const [planCount, setPlanCount] = useState(5);
  
  const t = translations[currentLang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (topic.trim() && slideCount > 0) {
      onGenerate(topic, slideCount, planCount, currentLang, description);
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto p-5 md:p-8 bg-white rounded-2xl shadow-xl border border-slate-100 relative overflow-hidden">
      
      <div className="text-center mb-6 md:mb-8 mt-2">
        <div className="inline-flex items-center justify-center p-3 bg-indigo-100 rounded-full mb-4">
          <Sparkles className="w-6 h-6 md:w-8 md:h-8 text-indigo-600" />
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900 mb-2">{t.headerTitle}</h1>
        <p className="text-sm md:text-base text-slate-500">{t.inputSubtitle}</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5 md:space-y-6">
        <div>
          <label htmlFor="topic" className="block text-sm font-medium text-slate-700 mb-2">
            {t.inputTopicLabel}
          </label>
          <input
            id="topic"
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder={t.inputTopicPlaceholder}
            className="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm md:text-base placeholder-slate-400"
            required
            disabled={isProcessing}
          />
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-2">
             <span className="flex items-center gap-1">
                 <FileText className="w-4 h-4" /> {t.inputDescLabel}
              </span>
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={t.inputDescPlaceholder}
            rows={2}
            className="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm md:text-base placeholder-slate-400 resize-none"
            disabled={isProcessing}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="language" className="block text-sm font-medium text-slate-700 mb-2">
              <span className="flex items-center gap-1">
                 <Globe className="w-4 h-4" /> {t.inputLangLabel}
              </span>
            </label>
            <select
              id="language"
              value={currentLang}
              onChange={(e) => onLanguageChange(e.target.value as Language)}
              className="w-full px-3 py-2 bg-white text-slate-900 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer text-sm"
              disabled={isProcessing}
            >
              <option value="uz">O'zbek</option>
              <option value="en">English</option>
              <option value="ru">Русский</option>
            </select>
          </div>

          <div>
            <label htmlFor="slideCount" className="block text-sm font-medium text-slate-700 mb-2">
               <span className="flex items-center gap-1">
                 <Layers className="w-4 h-4" /> {t.inputSlidesLabel}
              </span>
            </label>
            <select
              id="slideCount"
              value={slideCount}
              onChange={(e) => setSlideCount(Number(e.target.value))}
              className="w-full px-3 py-2 bg-white text-slate-900 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer text-sm"
              disabled={isProcessing}
            >
              <option value={10}>10</option>
              <option value={15}>15</option>
              <option value={20}>20</option>
              <option value={25}>25</option>
              <option value={30}>30</option>
            </select>
          </div>

          <div>
            <label htmlFor="planCount" className="block text-sm font-medium text-slate-700 mb-2">
              <span className="flex items-center gap-1">
                 <ListOrdered className="w-4 h-4" /> {t.inputPlanLabel}
              </span>
            </label>
            <select
              id="planCount"
              value={planCount}
              onChange={(e) => setPlanCount(Number(e.target.value))}
              className="w-full px-3 py-2 bg-white text-slate-900 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer text-sm"
              disabled={isProcessing}
            >
              <option value={3}>3</option>
              <option value={4}>4</option>
              <option value={5}>5</option>
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={isProcessing || !topic.trim()}
          className={`w-full flex items-center justify-center gap-2 py-3 md:py-4 px-6 rounded-xl text-white font-semibold text-base md:text-lg transition-all transform hover:scale-[1.02] active:scale-[0.98] ${
            isProcessing || !topic.trim()
              ? 'bg-slate-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:shadow-lg hover:shadow-indigo-500/30'
          }`}
        >
          {isProcessing ? t.btnGenerating : t.btnGenerate}
          {!isProcessing && <ArrowRight className="w-5 h-5" />}
        </button>
      </form>
    </div>
  );
};
