
import React from 'react';
import { Loader2, Image as ImageIcon, FileText } from 'lucide-react';
import { AppStatus, GenerationProgress, Language } from '../types';
import { translations } from '../utils/translations';

interface LoadingViewProps {
  status: AppStatus;
  progress: GenerationProgress;
  language: Language;
}

export const LoadingView: React.FC<LoadingViewProps> = ({ status, progress, language }) => {
  const t = translations[language];

  return (
    <div className="w-full max-w-md mx-auto text-center p-6 md:p-8 bg-white rounded-2xl shadow-lg border border-slate-100">
      <div className="relative flex items-center justify-center w-16 h-16 md:w-20 md:h-20 mx-auto mb-6">
        <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
        <div className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
        <Loader2 className="w-6 h-6 md:w-8 md:h-8 text-indigo-600 absolute" />
      </div>

      <h2 className="text-lg md:text-xl font-bold text-slate-900 mb-2">
        {status === AppStatus.GENERATING_PLAN ? t.loadingPlanTitle : t.loadingImageTitle}
      </h2>
      
      <p className="text-sm md:text-base text-slate-500 mb-6 md:mb-8">
        {status === AppStatus.GENERATING_PLAN 
          ? t.loadingPlanSub 
          : t.loadingImageSub}
      </p>

      {status === AppStatus.GENERATING_IMAGES && (
        <div className="space-y-2">
          <div className="flex justify-between text-sm font-medium text-slate-600 mb-1">
            <span className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4" /> {t.loadingImagesProgress}
            </span>
            <span>{progress.current} / {progress.total}</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
            <div 
              className="bg-indigo-600 h-full rounded-full transition-all duration-300 ease-out"
              style={{ width: `${(progress.current / progress.total) * 100}%` }}
            ></div>
          </div>
        </div>
      )}
      
      {status === AppStatus.GENERATING_PLAN && (
         <div className="flex items-center justify-center gap-2 text-indigo-600 bg-indigo-50 py-2 px-4 rounded-lg mt-4 animate-pulse">
            <FileText className="w-4 h-4" />
            <span className="text-sm font-medium">{t.loadingTextPulse}</span>
         </div>
      )}
    </div>
  );
};
