
import React, { useState, useEffect } from 'react';
import { Slide, Theme, UsageStats, Language } from '../types';
import { ChevronLeft, ChevronRight, RotateCcw, Download, Component, Sparkles, Loader2, Palette } from 'lucide-react';
import { generatePPTX } from '../utils/pptxGenerator';
import { THEMES } from '../utils/themes';
import { translations } from '../utils/translations';

interface SlideViewerProps {
  slides: Slide[];
  topic: string;
  theme: Theme;
  backgroundImages: string[];
  usageStats: UsageStats | null;
  onRestart: () => void;
  language: Language;
}

export const SlideViewer: React.FC<SlideViewerProps> = ({ slides, topic, theme: initialTheme, backgroundImages, usageStats, onRestart, language }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [activeTheme, setActiveTheme] = useState<Theme>(initialTheme);
  const [isDownloading, setIsDownloading] = useState(false);
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  
  const t = translations[language];

  useEffect(() => {
    setActiveTheme(initialTheme);
  }, [initialTheme]);

  const currentSlide = slides[currentIndex];
  const isFirst = currentIndex === 0;
  const isLast = currentIndex === slides.length - 1;
  const activeBackground = backgroundImages[0];

  const nextSlide = () => { if (!isLast) setCurrentIndex(prev => prev + 1); };
  const prevSlide = () => { if (!isFirst) setCurrentIndex(prev => prev - 1); };
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, isLast, isFirst]);

  // Helper function to strip leading numbers like "1. ", "1) ", "1- "
  const cleanContent = (text: string) => {
    return text.replace(/^\d+[\s.)-]+\s*/, '');
  };

  const handleDownload = async () => {
    setIsDownloading(true);
    try { await generatePPTX(topic, slides, activeTheme, activeBackground); } 
    catch (error) { console.error(error); alert("Error!"); }
    setIsDownloading(false);
  };

  const SubtleGraphics = () => (
    <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <svg width="800" height="800" viewBox="0 0 100 100" className="opacity-10">
          <circle cx="50" cy="50" r="45" stroke={activeTheme.colors.primary} strokeWidth="0.1" fill="none" />
          <path d="M50 5 L50 95 M5 50 L95 50" stroke={activeTheme.colors.primary} strokeWidth="0.05" />
        </svg>
      </div>
      <div className="absolute top-0 right-0 w-64 h-64 blur-3xl opacity-30" style={{ background: activeTheme.colors.accent }}></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 blur-3xl opacity-20" style={{ background: activeTheme.colors.primary }}></div>
    </div>
  );

  const renderContent = () => {
    const styleTitle = { color: activeTheme.colors.secondary };
    const styleText = { color: activeTheme.colors.text };
    const styleBullet = { backgroundColor: activeTheme.colors.primary };

    // Logika: Agar kontent 3 tadan kam bo'lsa yoki matn juda uzun bo'lsa, bu ro'yxat emas, balki paragraf.
    const isList = currentSlide.content.length > 3 || (currentSlide.content.length > 1 && currentSlide.content.every(c => c.length < 60));
    
    // Agar ro'yxat bo'lmasa, matnlarni birlashtirib yoki alohida paragraf qilib ko'rsatish
    const TextContent = () => (
      <div className="flex flex-col justify-center h-full max-w-4xl bg-white/40 backdrop-blur-md p-6 md:p-8 rounded-[1.5rem] md:rounded-[2rem] border border-white/40 shadow-xl">
        <h2 className="text-xl md:text-3xl font-black mb-4 md:mb-6 flex items-center gap-3" style={styleTitle}>
          <div className="w-8 h-1 md:w-10 md:h-1.5 rounded-full" style={{ background: activeTheme.colors.accent }}></div>
          {currentSlide.title}
        </h2>
        
        {isList ? (
          <ul className={`space-y-3 md:space-y-4 ${currentSlide.content.length > 5 ? 'grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-2' : ''}`}>
            {currentSlide.content.map((point, idx) => (
              <li key={idx} className="flex items-start gap-3 md:gap-4 text-sm md:text-lg font-semibold" style={styleText}>
                <div className="mt-1 w-5 h-5 md:w-6 md:h-6 rounded-lg flex items-center justify-center flex-shrink-0 text-[10px] md:text-[12px] font-bold text-white shadow-md" style={styleBullet}>{idx + 1}</div>
                <span className="leading-snug drop-shadow-sm">{cleanContent(point)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <div className="space-y-4">
             {currentSlide.content.map((paragraph, idx) => (
               <p key={idx} className="text-base md:text-xl leading-relaxed font-medium drop-shadow-sm" style={styleText}>
                 {cleanContent(paragraph)}
               </p>
             ))}
          </div>
        )}
      </div>
    );

    if (currentSlide.layout === 'title') {
      return (
        <div className="h-full flex flex-col items-center justify-center text-center p-6 md:p-12">
          <SubtleGraphics />
          <div className="relative z-10 bg-white/30 backdrop-blur-lg p-8 md:p-12 rounded-[2rem] md:rounded-[4rem] border border-white/40 shadow-2xl w-full max-w-3xl">
            <Sparkles className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-6 md:mb-8" style={{ color: activeTheme.colors.primary }} />
            <h1 className="text-3xl md:text-7xl font-black mb-6 md:mb-8 leading-tight drop-shadow-xl break-words" style={{ color: activeTheme.colors.primary }}>{currentSlide.title}</h1>
            <div className="h-1.5 md:h-2 w-24 md:w-32 bg-current mx-auto mb-8 md:mb-10 rounded-full" style={{ color: activeTheme.colors.accent }}></div>
            <p className="text-lg md:text-3xl font-bold opacity-90 drop-shadow-lg" style={styleText}>{cleanContent(currentSlide.content[0] || "")}</p>
          </div>
        </div>
      );
    }

    if (currentSlide.imageData) {
      return (
        <div className="h-full flex flex-col md:flex-row p-6 md:p-10 gap-6 md:gap-10 items-center overflow-y-auto md:overflow-hidden">
          <div className="w-full md:flex-[1.2] flex flex-col justify-center order-2 md:order-1"><TextContent /></div>
          <div className="w-full md:flex-1 h-64 md:h-5/6 order-1 md:order-2 flex-shrink-0">
            <div className="w-full h-full rounded-[1.5rem] md:rounded-[2.5rem] overflow-hidden shadow-2xl border-4 md:border-8 border-white/50 relative group">
               <img src={currentSlide.imageData} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
               <div className="absolute inset-0 ring-1 ring-inset ring-black/5 rounded-[1.5rem] md:rounded-[2.5rem]"></div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="h-full p-6 md:p-20 flex flex-col justify-center relative overflow-y-auto">
        <SubtleGraphics />
        <div className="relative z-10 py-4"><TextContent /></div>
        <div className="absolute top-1/2 right-20 -translate-y-1/2 opacity-5 hidden lg:block animate-pulse">
           <Component className="w-96 h-96" style={{ color: activeTheme.colors.primary }} />
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col h-full py-2 md:py-4">
      {/* Top Buttons */}
      <div className="flex flex-wrap items-center justify-between mb-4 px-2 gap-2">
        <button onClick={onRestart} className="flex items-center gap-2 text-slate-600 hover:text-indigo-600 font-bold text-xs md:text-sm bg-white px-4 py-2 md:px-5 md:py-2.5 rounded-xl md:rounded-2xl shadow-sm border border-slate-100 transition-colors">
          <RotateCcw className="w-3.5 h-3.5 md:w-4 md:h-4" /> 
          <span className="hidden sm:inline">{t.btnRestart}</span>
          <span className="sm:hidden">Yangilash</span>
        </button>
        <button onClick={handleDownload} disabled={isDownloading} className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2 md:px-7 md:py-2.5 rounded-xl md:rounded-2xl text-xs md:text-sm font-black shadow-lg hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-80 disabled:cursor-wait">
          {isDownloading ? (
            <>
              <Loader2 className="w-3.5 h-3.5 md:w-4 md:h-4 animate-spin" />
              {t.btnDownloading}
            </>
          ) : (
            <>
              <Download className="w-3.5 h-3.5 md:w-4 md:h-4" /> 
              {t.btnDownload}
            </>
          )}
        </button>
      </div>

      {/* Main Slide Display */}
      {/* Mobileda aspect-video ni o'chiramiz va min-height beramiz, shunda kontent sig'adi */}
      <div className="relative w-full md:aspect-video min-h-[550px] md:min-h-0 rounded-[2rem] md:rounded-[3.5rem] shadow-[0_20px_50px_-10px_rgba(0,0,0,0.3)] md:shadow-[0_45px_100px_-20px_rgba(0,0,0,0.4)] bg-white overflow-hidden border-[8px] md:border-[12px] border-white/80 backdrop-blur-sm">
        <div className="absolute inset-0 transition-all duration-700" style={{ fontFamily: activeTheme.font, backgroundColor: activeTheme.colors.background }}>
           {activeBackground && (
             <div className="absolute inset-0 z-0 overflow-hidden">
                <img src={activeBackground} className="w-full h-full object-cover opacity-30 mix-blend-multiply scale-105" alt="Background" />
                <div className="absolute inset-0 bg-gradient-to-tr from-white/20 via-transparent to-black/5"></div>
             </div>
           )}
           <div className="relative z-10 h-full w-full">{renderContent()}</div>
           <div className="absolute bottom-4 right-6 md:bottom-8 md:right-12 text-[10px] md:text-[12px] font-black opacity-60 z-20 px-3 py-1.5 md:px-4 md:py-2 bg-white/40 rounded-full backdrop-blur-md shadow-sm" style={{ color: activeTheme.colors.text }}>{currentIndex + 1} / {slides.length}</div>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="flex items-center justify-center mt-6 md:mt-10 gap-4 md:gap-10">
        <button onClick={prevSlide} disabled={isFirst} className={`p-4 md:p-6 rounded-[1.5rem] md:rounded-[2rem] shadow-xl transition-all ${isFirst ? 'bg-slate-100 text-slate-300 cursor-not-allowed opacity-50' : 'bg-white text-slate-800 hover:bg-indigo-50 hover:-translate-x-1 active:scale-90'}`}>
          <ChevronLeft className="w-6 h-6 md:w-8 md:h-8" />
        </button>
        
        <div className="relative">
          <button onClick={() => setShowThemeSelector(!showThemeSelector)} className="text-[10px] md:text-[12px] font-black text-slate-600 px-5 py-3 md:px-10 md:py-5 rounded-[1.5rem] md:rounded-[2rem] bg-white shadow-xl border border-slate-100 flex items-center gap-2 md:gap-4 uppercase tracking-wider hover:text-indigo-600 transition-all whitespace-nowrap">
            <div className="w-3 h-3 md:w-4 md:h-4 rounded-full shadow-inner ring-2 ring-slate-100" style={{ background: activeTheme.colors.primary }}></div>
            <span className="hidden md:inline">{t.themeSelector}:</span> {activeTheme.name}
            <span className="md:hidden"><Palette className="w-4 h-4" /></span>
          </button>
          {showThemeSelector && (
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-4 md:mb-6 bg-white/95 backdrop-blur-2xl rounded-[2rem] md:rounded-[2.5rem] shadow-[0_30px_70px_rgba(0,0,0,0.3)] border border-white/50 p-3 md:p-4 w-56 md:w-64 z-50 animate-in fade-in zoom-in-95 duration-200">
               <div className="grid gap-2">
                 {Object.values(THEMES).map((t) => (
                  <button key={t.id} onClick={() => { setActiveTheme(t); setShowThemeSelector(false); }} className={`w-full flex items-center justify-between px-4 py-3 md:px-5 md:py-4 rounded-xl md:rounded-2xl text-[10px] md:text-[11px] font-black uppercase transition-all ${activeTheme.id === t.id ? 'bg-indigo-600 text-white shadow-lg scale-[1.02]' : 'hover:bg-indigo-50 text-slate-700'}`}>
                    {t.name} 
                    <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 md:w-3 md:h-3 rounded-full ring-1 ring-white/30" style={{ background: t.colors.primary }}></div>
                      <div className="w-2.5 h-2.5 md:w-3 md:h-3 rounded-full ring-1 ring-white/30" style={{ background: t.colors.background }}></div>
                    </div>
                  </button>
                 ))}
               </div>
            </div>
          )}
        </div>

        <button onClick={nextSlide} disabled={isLast} className={`p-4 md:p-6 rounded-[1.5rem] md:rounded-[2rem] shadow-xl transition-all ${isLast ? 'bg-slate-100 text-slate-300 cursor-not-allowed opacity-50' : 'bg-indigo-600 text-white hover:bg-indigo-700 hover:translate-x-1 active:scale-90'}`} style={!isLast ? { backgroundColor: activeTheme.colors.primary } : {}}><ChevronRight className="w-6 h-6 md:w-8 md:h-8" /></button>
      </div>
    </div>
  );
};
