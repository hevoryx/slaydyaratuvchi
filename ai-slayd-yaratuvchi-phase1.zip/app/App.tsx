
import React, { useState, useRef, useEffect } from 'react';
import { InputForm } from './components/InputForm';
import { LoadingView } from './components/LoadingView';
import { SlideViewer } from './components/SlideViewer';
import { generatePresentationPlan, generateSlideImage, getProviderStatus, ApiClientError } from './services/geminiService';
import { AppStatus, Slide, GenerationProgress, Theme, Language } from './types';
import { getTheme } from './utils/themes';
import { translations } from './utils/translations';
import { AlertCircle, AlertTriangle } from 'lucide-react';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [topic, setTopic] = useState<string>('');
  const [slides, setSlides] = useState<Slide[]>([]);
  const [theme, setTheme] = useState<Theme>(getTheme('modern_blue'));
  const [backgroundImage, setBackgroundImage] = useState<string | null>(null);
  const [progress, setProgress] = useState<GenerationProgress>({ current: 0, total: 0 });
  const [error, setError] = useState<string | null>(null);
  const [language, setLanguage] = useState<Language>('uz');
  const [warning, setWarning] = useState<string | null>(null);
  const [needsKey, setNeedsKey] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    getProviderStatus().then(s => setNeedsKey(s !== null && !s.gemini.configured));
    return () => abortRef.current?.abort();
  }, []);

  const handleGenerate = async (inputTopic: string, slideCount: number, planCount: number, selectedLang: Language, additionalInfo?: string) => {
    setTopic(inputTopic);
    setStatus(AppStatus.GENERATING_PLAN);
    setError(null);
    setSlides([]);
    setBackgroundImage(null);
    setWarning(null);
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    const { signal } = ctrl;

    try {
      // 1. Reja va mavzuni aniqlash
      const planResponse = await generatePresentationPlan(inputTopic, slideCount, planCount, selectedLang, additionalInfo, signal);
      setTheme(getTheme(planResponse.themeId));
      setSlides(planResponse.slides);
      
      const failures: string[] = [];
      // 2. Orqa fon rasmini yaratish (agar prompt bo'lsa)
      if (planResponse.backgroundVisualPrompt) {
        try { setBackgroundImage(await generateSlideImage(planResponse.backgroundVisualPrompt, true, signal)); }
        catch (e) { if (signal.aborted) return; failures.push((e as Error).message); }
      }

      // 3. Slayd rasmlarini aniqlash va yaratish
      const slidesToImage = planResponse.slides.filter(s => s.imagePrompt && s.imagePrompt.length > 5);
      const totalImages = slidesToImage.length;
      
      if (totalImages > 0) {
        setStatus(AppStatus.GENERATING_IMAGES);
        setProgress({ current: 0, total: totalImages });

        const updatedSlides = [...planResponse.slides];
        let imagesCompleted = 0;
        
        // Har bir slayd uchun rasm generatsiyasi
        for (let i = 0; i < updatedSlides.length; i++) {
          if (updatedSlides[i].imagePrompt && updatedSlides[i].imagePrompt!.length > 5) {
            try {
              updatedSlides[i].imageData = await generateSlideImage(updatedSlides[i].imagePrompt!, false, signal);
              setSlides([...updatedSlides]);
            } catch (e) {
              if (signal.aborted) return;
              failures.push((e as Error).message); // one failed image must not stop the rest
            }
            imagesCompleted++;
            setProgress(prev => ({ ...prev, current: imagesCompleted }));
          }
        }
      }

      if (failures.length) setWarning(`${failures.length} image(s) could not be generated: ${failures[0]} You can still export the slides without them.`);
      setStatus(AppStatus.READY);

    } catch (err: any) {
      if (signal.aborted) return;
      setError(err instanceof ApiClientError ? err.message : translations[language].errorTitle);
      setStatus(AppStatus.ERROR);
    }
  };

  const handleRestart = () => {
    abortRef.current?.abort();
    setWarning(null);
    setStatus(AppStatus.IDLE);
    setSlides([]);
    setBackgroundImage(null);
  };

  const t = translations[language];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans transition-all duration-500 overflow-hidden">
      
      <header className="bg-white border-b border-slate-200 py-3 px-4 md:px-6 flex items-center justify-between z-50 shadow-sm sticky top-0">
         <div className="flex items-center gap-2 font-bold text-lg text-indigo-600">
            <div className="bg-indigo-600 text-white rounded-lg w-7 h-7 flex items-center justify-center text-sm shrink-0">AI</div>
            <span className="truncate">{t.headerTitle}</span>
         </div>
      </header>

      {needsKey && (
        <div role="alert" className="bg-amber-50 border-b border-amber-200 text-amber-900 text-sm px-4 py-2 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>Gemini API key is not configured on the server. Copy <code>.env.example</code> to <code>.env.local</code>, set <code>GEMINI_API_KEY</code>, and restart the server.</span>
        </div>
      )}
      {warning && (
        <div role="status" className="bg-amber-50 border-b border-amber-200 text-amber-900 text-sm px-4 py-2 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" /><span>{warning}</span>
        </div>
      )}

      <main className="flex-1 flex flex-col items-center justify-center p-2 md:p-4 relative w-full">
        {status === AppStatus.IDLE && (
          <InputForm 
            onGenerate={handleGenerate} 
            isProcessing={false} 
            onLanguageChange={setLanguage}
            currentLang={language}
          />
        )}
        {(status === AppStatus.GENERATING_PLAN || status === AppStatus.GENERATING_IMAGES) && (
          <LoadingView status={status} progress={progress} language={language} />
        )}
        {status === AppStatus.READY && (
          <SlideViewer 
            slides={slides} 
            topic={topic} 
            theme={theme}
            backgroundImages={backgroundImage ? [backgroundImage] : []}
            usageStats={null}
            onRestart={handleRestart} 
            language={language}
          />
        )}
        {status === AppStatus.ERROR && (
          <div className="max-w-md w-full bg-white p-6 md:p-8 rounded-2xl shadow-lg text-center border border-red-100 mx-4">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <p className="text-slate-600 mb-6 font-medium">{error}</p>
            <button 
              onClick={handleRestart} 
              className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg w-full md:w-auto"
            >
              {t.btnRetry}
            </button>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
