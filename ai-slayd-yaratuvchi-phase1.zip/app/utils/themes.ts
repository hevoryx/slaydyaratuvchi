
import { Theme } from '../types';

export const THEMES: Record<string, Theme> = {
  modern_blue: {
    id: 'modern_blue',
    name: 'Modern Blue',
    colors: {
      primary: '#2563eb', // blue-600
      secondary: '#1e3a8a', // blue-900
      accent: '#38bdf8', // sky-400
      background: '#ffffff',
      text: '#0f172a', // slate-900
      textLight: '#475569', // slate-600
    },
    font: 'Inter'
  },
  nature_green: {
    id: 'nature_green',
    name: 'Nature Calm',
    colors: {
      primary: '#059669', // emerald-600
      secondary: '#064e3b', // emerald-900 (Deep Green for better visibility)
      accent: '#10b981', // emerald-500
      background: '#f0fdf4', // emerald-50 (Very light background)
      text: '#064e3b', // Dark green for text
      textLight: '#065f46',
    },
    font: 'Inter'
  },
  creative_purple: {
    id: 'creative_purple',
    name: 'Creative Bold',
    colors: {
      primary: '#7c3aed', // violet-600
      secondary: '#4c1d95', // violet-950
      accent: '#f472b6', // pink-400
      background: '#ffffff',
      text: '#2e1065', // violet-950
      textLight: '#5b21b6', // violet-800
    },
    font: 'Inter'
  },
  minimal_dark: {
    id: 'minimal_dark',
    name: 'Elegant Dark',
    colors: {
      primary: '#f8fafc', // white-ish
      secondary: '#94a3b8', // slate-400
      accent: '#0ea5e9', // sky-500
      background: '#020617', // slate-950
      text: '#f1f5f9', // slate-100
      textLight: '#cbd5e1', // slate-300
    },
    font: 'Inter'
  },
  midnight_gold: {
    id: 'midnight_gold',
    name: 'Midnight Gold',
    colors: {
      primary: '#fbbf24', // amber-400 (Gold)
      secondary: '#f59e0b', // amber-500
      accent: '#fbbf24',
      background: '#0f172a', // slate-900 (Dark Navy)
      text: '#f8fafc',
      textLight: '#cbd5e1',
    },
    font: 'Inter'
  },
  soft_rose: {
    id: 'soft_rose',
    name: 'Soft Rose',
    colors: {
      primary: '#e11d48', // rose-600
      secondary: '#881337', // rose-900
      accent: '#fb7185', // rose-400
      background: '#fff1f2', // rose-50
      text: '#4c0519', // rose-950
      textLight: '#9f1239',
    },
    font: 'Inter'
  },
  tech_cyan: {
    id: 'tech_cyan',
    name: 'Tech Cyan',
    colors: {
      primary: '#06b6d4', // cyan-500
      secondary: '#083344', // cyan-950
      accent: '#22d3ee', // cyan-400
      background: '#ecfeff', // cyan-50
      text: '#083344',
      textLight: '#155e75',
    },
    font: 'Inter'
  }
};

export const getTheme = (id: string): Theme => {
  return THEMES[id] || THEMES.modern_blue;
};
