
import pptxgen from "pptxgenjs";
import { Slide, Theme } from "../types";

export const generatePPTX = async (topic: string, slides: Slide[], theme: Theme, backgroundImage?: string) => {
  const pres = new pptxgen();

  pres.title = topic;
  pres.layout = 'LAYOUT_16x9';
  
  const c = (hex: string) => hex.replace('#', '');

  // Helper function to strip leading numbers
  const cleanContent = (text: string) => {
    return text.replace(/^\d+[\s.)-]+\s*/, '');
  };

  // Master Slide Setup
  pres.defineSlideMaster({
    title: "MASTER_SLIDE",
    background: { color: c(theme.colors.background) },
    objects: [
      // Orqa fon rasmi
      ...(backgroundImage ? [{
          image: { 
              x: 0, y: 0, w: 10, h: 5.625, 
              data: backgroundImage,
              sizing: { type: 'cover' as const, w: 10, h: 5.625 }
          }
      },
      // Orqa fonni biroz xiralashtirish - Webdagidek tiniqroq qilish uchun transparency: 75 (25% rang)
      {
          rect: { 
              x: 0, y: 0, w: 10, h: 5.625, 
              fill: { color: c(theme.colors.background), transparency: 75 } 
          }
      }] : []),
      
      // Grafik bezaklar
      {
        rect: { x: 2.5, y: 1.0, w: 5.0, h: 3.6, line: { color: c(theme.colors.primary), width: 0.5, transparency: 85 }, fill: { transparency: 100 } }
      },
      // Accent bar
      { rect: { x: 0.5, y: 0.2, w: 0.8, h: 0.05, fill: { color: c(theme.colors.accent) } } },
    ],
    slideNumber: { x: 9.3, y: 5.3, w: 0.5, h: 0.3, align: "right", color: c(theme.colors.text), fontSize: 9 }
  });

  for (const [index, slide] of slides.entries()) {
    const pptxSlide = pres.addSlide({ masterName: "MASTER_SLIDE" });
    const isTitleLayout = slide.layout === 'title';

    if (isTitleLayout) {
      // Titul slayd uchun markaziy karta
      pptxSlide.addShape(pres.ShapeType.rect, {
        x: 1.2, y: 1.0, w: 7.6, h: 3.6,
        fill: { color: 'FFFFFF', transparency: 50 }, 
        line: { color: c(theme.colors.primary), width: 1.5, transparency: 60 },
        rectRadius: 0.5
      });

      pptxSlide.addText(slide.title.toUpperCase(), {
        x: 1.5, y: 1.6, w: 7.0, h: 1.0,
        fontSize: 38,
        color: c(theme.colors.primary),
        bold: true,
        align: 'center',
        fontFace: theme.font
      });
      
      pptxSlide.addShape(pres.ShapeType.line, { x: 4.25, y: 2.8, w: 1.5, h: 0, line: { color: c(theme.colors.accent), width: 4 } });

      // Faqat bitta mazmunli gap va raqamsiz
      pptxSlide.addText(cleanContent(slide.content[0] || ""), {
        x: 1.5, y: 3.1, w: 7.0, h: 0.6,
        fontSize: 20,
        color: c(theme.colors.text),
        align: 'center',
        fontFace: theme.font,
        bold: true
      });

    } else {
      // Boshqa slaydlar uchun matn foni
      const contentW = slide.imageData ? 5.2 : 9.0;
      
      pptxSlide.addShape(pres.ShapeType.rect, {
        x: 0.4, y: 0.4, w: contentW + 0.2, h: 4.8,
        fill: { color: 'FFFFFF', transparency: 50 }, 
        line: { color: c(theme.colors.accent), width: 1, transparency: 70 },
        rectRadius: 0.3
      });

      // Sarlavha: Joylashuvi va o'lchami o'zgartirildi (Overlapping fix)
      pptxSlide.addText(slide.title, {
        x: 0.6, y: 0.5, w: contentW - 0.2, h: 1.2,
        fontSize: 24, // Biroz kichraytirildi (26 dan 24 ga)
        color: c(theme.colors.secondary),
        bold: true,
        fontFace: theme.font,
        valign: 'top' // Yuqoridan tekislash
      });

      const startY = 1.8; // Matn boshlanish joyi pastga surildi (1.3 dan 1.8 ga)

      // Matn turi (Ro'yxat yoki Paragraf)
      const isList = slide.content.length > 3 || (slide.content.length > 1 && slide.content.every(c => c.length < 60));

      if (isList) {
        // Ro'yxat ko'rinishi
        const columnCount = (!slide.imageData && slide.content.length > 5) ? 2 : 1;
        
        slide.content.forEach((point, i) => {
          const col = i % columnCount;
          const row = Math.floor(i / columnCount);
          const colW = columnCount === 1 ? contentW - 0.4 : (contentW / 2) - 0.4;

          const numberedText = `${i + 1}. ${cleanContent(point)}`;

          pptxSlide.addText(numberedText, {
            x: 0.8 + (col * (colW + 0.2)),
            y: startY + (row * 0.6), // Qatorlar orasi biroz kengaytirildi
            w: colW,
            h: 0.5,
            fontSize: 16,
            color: c(theme.colors.text),
            fontFace: theme.font,
            bold: true
          });
        });
      } else {
        // Paragraf ko'rinishi (Raqamsiz, katta matn bloki)
        const fullText = slide.content.map(c => cleanContent(c)).join('\n\n');
        
        pptxSlide.addText(fullText, {
          x: 0.8, y: startY, w: contentW - 0.4, h: 3.2,
          fontSize: 18, // Kattaroq shrift o'qish uchun
          color: c(theme.colors.text),
          fontFace: theme.font,
          valign: 'top',
          align: 'left',
          bold: false // Paragraf uchun qalin shrift shart emas
        });
      }

      if (slide.imageData) {
        // Rasm ramkasi
        pptxSlide.addShape(pres.ShapeType.rect, { 
          x: 6.0, y: 0.8, w: 3.6, h: 4.0, 
          fill: { color: 'FFFFFF', transparency: 20 }, 
          line: { color: c(theme.colors.primary), width: 4 },
          rectRadius: 0.3
        });
        
        pptxSlide.addImage({
          data: slide.imageData,
          x: 6.1, y: 0.9, w: 3.4, h: 3.8,
          sizing: { type: 'cover', w: 3.4, h: 3.8 }
        });
      }
    }
  }

  const safeTopic = topic.replace(/[^a-z0-9а-яА-Я\s-]/gi, '').trim().replace(/\s+/g, '_').substring(0, 30);
  const fileName = `${safeTopic || 'taqdimot'}.pptx`;
  
  await pres.writeFile({ fileName });
};
