

const getLanguageName = (lang) => {
  switch(lang) {
    case 'uz': return "O'zbek";
    case 'en': return "English";
    case 'ru': return "Русский";
    default: return "O'zbek";
  }
};

export const SYSTEM_INSTRUCTION_PLAN = (language) => {
  const langName = getLanguageName(language);
  return `Siz professional taqdimot ustasisiz. Asosiy qoidalaringiz:

1. **REJA INTIZOMI:** Sizga berilgan reja punktlaridan aslo chetga chiqmang. Slaydlar ketma-ketligi reja mantiqiga qat'iy amal qilishi shart. Har bir reja punkti uchun bir nechta slayd yarating.
2. **KONTENT USLUBI (70/30 qoidasi):** 
   - Slaydlarning 70-80% qismida quruq raqamli ro'yxatlar (1, 2, 3...) ISHLATMANG. 
   - Buning o'rniga: Umumiy faktlar, qiziqarli ma'lumotlar, ixcham paragraflar yoki katta g'oyalarni yozing.
   - Raqamli ro'yxatlarni faqat bosqichma-bosqich jarayonlar yoki aniq sanalmalar uchun ishlating.
3. **TIL:** ${langName} tilida mukammal va ravon yozing.
4. **VISUAL:** Har bir slayd uchun (tituldan tashqari) ingliz tilida "imagePrompt" yozing. Uslub: Cinematic, Photorealistic. "NO text" deb belgilang.`;
};

export const createPlanPrompt = (topic, slideCount, planCount, language, additionalInfo) => {
  const langName = getLanguageName(language);
  
  let promptText = `Mavzu: "${topic}". 
Jami slaydlar soni: ${slideCount} ta. 
Reja punktlari soni: ${planCount} ta. 
Taqdimot tili: ${langName}.`;

  if (additionalInfo && additionalInfo.trim() !== "") {
    promptText += `\nQo'shimcha yo'riqnoma: "${additionalInfo}". (Ushbu tavsifga alohida e'tibor bering).`;
  }

  promptText += `\n\nUshbu mavzu bo'yicha professional taqdimot yaratib bering.

QAT'IY TALABLAR:

1. **STRUKTURA VA REJA:**
   - Avval ${planCount} ta punktdan iborat mantiqiy reja tuzing.
   - Jami ${slideCount} ta slaydni ushbu reja punktlari bo'yicha taqsimlang.
   - Masalan: Kirish (1 slayd), 1-punkt (3 slayd), 2-punkt (3 slayd)... Xulosa (1 slayd).
   - HAR BIR SLAYD Sarlavhasi (title) qaysi reja punktiga tegishli ekanligini aniq ochib bersin. Mavzudan tashqari gaplar bo'lmasin.

2. **MAZMUN (CONTENT) FORMATI:**
   - Iltimos, slaydlarni faqat raqamli ro'yxat (list) qilib tashlamang!
   - **Content massivi:** 
     - Agar slayd ma'lumot beruvchi bo'lsa (tarix, ta'rif, fakt), 'content' massiviga 1 yoki 2 ta uzunroq, to'liq gap kiriting (Paragraf uslubida).
     - Agar slayd sanab o'tishni talab qilsa, 3-5 ta qisqa gap kiriting (Ro'yxat uslubida).
   - 80% holatda matnlar o'qishli, ravon hikoya yoki fakt ko'rinishida bo'lsin.

3. **DIZAYN VA RASMLAR:**
   - Mavzuga mos 'themeId' tanlang.
   - 'backgroundVisualPrompt': Butun taqdimot uchun yagona, abstrakt, matnsiz fon rasmi prompti.
   - 'imagePrompt': Har bir slayd mazmuniga mos realistik rasm prompti (Ingliz tilida).

Javobni JSON formatida qaytaring:
{
  "themeId": "...",
  "backgroundVisualPrompt": "...",
  "slides": [
    {
      "title": "Slayd sarlavhasi (Reja punktiga mos)",
      "content": ["Matn 1", "Matn 2"], (Paragraf yoki ro'yxat),
      "layout": "image_split" yoki "centered" yoki "bullet_points_right",
      "imagePrompt": "..."
    },
    ...
  ]
}`;

  return promptText;
};

export const createImagePrompt = (basePrompt, isBackground = false) => {
  const styles = "Cinematic photography, award-winning photo, 8k resolution, highly detailed texture, depth of field, natural lighting, shot on 35mm lens, photorealistic";
  const negativePrompts = "NO text, NO watermark, NO illustration, NO 3d render style, NO vector art, NO cartoon, NO painting, NO letters, NO words, NO signage";
  
  if (isBackground) {
    return `${basePrompt}, minimalist, soft focus, blurred background, ${styles}. ${negativePrompts}`;
  }
  
  return `${basePrompt}, ${styles}. Real world style. ${negativePrompts}`;
};
