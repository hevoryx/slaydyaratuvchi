// Local backend: keeps the Gemini API key on the server, validates input,
// applies timeouts/retries and maps provider errors to readable messages.
// No third-party HTTP framework; only Node built-ins + @google/genai.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SYSTEM_INSTRUCTION_PLAN, createPlanPrompt, createImagePrompt } from './prompts.mjs';

for (const f of ['.env.local', '.env']) { try { process.loadEnvFile(f); } catch { /* optional */ } }

const PORT = Number(process.env.PORT || 3001);
const HOST = process.env.HOST || '127.0.0.1';
const TEXT_MODEL = process.env.GEMINI_TEXT_MODEL || 'gemini-2.5-flash';
const IMAGE_MODEL = process.env.GEMINI_IMAGE_MODEL || 'gemini-2.5-flash-image';
const TIMEOUT_MS = Number(process.env.REQUEST_TIMEOUT_MS || 60000);
const LANGS = ['uz', 'en', 'ru'];
const THEME_IDS = ['modern_blue', 'nature_green', 'creative_purple', 'minimal_dark', 'midnight_gold', 'soft_rose', 'tech_cyan'];
const LAYOUTS = ['title', 'bullet_points_left', 'bullet_points_right', 'centered', 'image_split'];
const DIST = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');

class ApiError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

let client;
async function getClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new ApiError(503, 'NO_API_KEY', 'GEMINI_API_KEY is not set. Copy .env.example to .env.local, add your key from https://aistudio.google.com/app/apikey and restart the server.');
  if (!client) { const { GoogleGenAI } = await import('@google/genai'); client = new GoogleGenAI({ apiKey }); }
  return client;
}

// Map provider failures to messages that say what happened and how to fix it.
function mapProviderError(e) {
  if (e instanceof ApiError) return e;
  const status = Number(e?.status || e?.code) || 0;
  if (e?.name === 'AbortError' || e?.code === 'TIMEOUT') return new ApiError(504, 'TIMEOUT', 'The AI provider did not respond in time. Try again, or reduce the number of slides.');
  if (status === 400 && /API key/i.test(String(e?.message))) return new ApiError(401, 'BAD_KEY', 'The Gemini API key was rejected. Check GEMINI_API_KEY in .env.local.');
  if (status === 401 || status === 403) return new ApiError(401, 'BAD_KEY', 'The Gemini API key is invalid or lacks access to this model.');
  if (status === 404) return new ApiError(502, 'BAD_MODEL', 'The configured Gemini model was not found. Check GEMINI_TEXT_MODEL / GEMINI_IMAGE_MODEL.');
  if (status === 429) return new ApiError(429, 'RATE_LIMIT', 'Gemini rate limit or quota reached. Wait a minute and retry, or check your quota.');
  if (status >= 500) return new ApiError(502, 'PROVIDER', 'The AI provider had a temporary error. Try again shortly.');
  if (e?.cause?.code || /fetch failed|ENOTFOUND|ECONN/i.test(String(e?.message))) return new ApiError(502, 'NETWORK', 'Could not reach the AI provider. Check your internet connection.');
  return new ApiError(500, 'UNKNOWN', 'Unexpected error while calling the AI provider.');
}

const retryable = (e) => { const s = Number(e?.status || e?.code) || 0; return s === 429 || s >= 500 || e?.cause?.code; };

async function withRetry(fn, { retries = 2, signal } = {}) {
  for (let attempt = 0; ; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
    const onAbort = () => ctrl.abort();
    signal?.addEventListener('abort', onAbort);
    try { return await fn(ctrl.signal); }
    catch (e) {
      if (signal?.aborted) throw new ApiError(499, 'CANCELLED', 'Request cancelled.');
      if (attempt >= retries || !retryable(e)) throw mapProviderError(e);
      await new Promise((r) => setTimeout(r, 800 * 2 ** attempt));
    } finally { clearTimeout(timer); signal?.removeEventListener('abort', onAbort); }
  }
}

// ---- validation ----
const str = (v, max, name, req = true) => {
  if (v == null || v === '') { if (req) throw new ApiError(400, 'BAD_INPUT', `${name} is required.`); return ''; }
  if (typeof v !== 'string') throw new ApiError(400, 'BAD_INPUT', `${name} must be text.`);
  if (v.length > max) throw new ApiError(400, 'BAD_INPUT', `${name} is too long (max ${max} characters).`);
  return v.trim();
};
const int = (v, min, max, name) => {
  if (!Number.isInteger(v) || v < min || v > max) throw new ApiError(400, 'BAD_INPUT', `${name} must be a whole number between ${min} and ${max}.`);
  return v;
};
function validatePlan(b) {
  const language = LANGS.includes(b.language) ? b.language : (() => { throw new ApiError(400, 'BAD_INPUT', `language must be one of ${LANGS.join(', ')}.`); })();
  return {
    topic: str(b.topic, 300, 'topic'), language,
    slideCount: int(b.slideCount, 1, 40, 'slideCount'), planCount: int(b.planCount, 1, 10, 'planCount'),
    additionalInfo: str(b.additionalInfo, 2000, 'additionalInfo', false),
  };
}

// ---- handlers ----
const inflight = new Set(); // block accidental identical duplicate requests
async function once(key, fn) {
  if (inflight.has(key)) throw new ApiError(409, 'DUPLICATE', 'An identical request is already running.');
  inflight.add(key);
  try { return await fn(); } finally { inflight.delete(key); }
}

async function handlePlan(body, signal) {
  const p = validatePlan(body);
  const ai = await getClient();
  const { Type } = await import('@google/genai');
  return once('plan:' + JSON.stringify(p), () => withRetry(async (sig) => {
    const res = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: createPlanPrompt(p.topic, p.slideCount, p.planCount, p.language, p.additionalInfo),
      config: {
        abortSignal: sig,
        systemInstruction: SYSTEM_INSTRUCTION_PLAN(p.language),
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            themeId: { type: Type.STRING, enum: THEME_IDS },
            backgroundVisualPrompt: { type: Type.STRING },
            slides: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: {
              title: { type: Type.STRING }, content: { type: Type.ARRAY, items: { type: Type.STRING } },
              layout: { type: Type.STRING, enum: LAYOUTS }, imagePrompt: { type: Type.STRING } },
              required: ['title', 'content', 'layout', 'imagePrompt'] } },
          },
          required: ['themeId', 'slides', 'backgroundVisualPrompt'],
        },
      },
    });
    let parsed;
    try { parsed = JSON.parse(res.text || ''); } catch { throw new ApiError(502, 'BAD_RESPONSE', 'The AI returned an unreadable response. Please try again.'); }
    if (!Array.isArray(parsed.slides) || parsed.slides.length === 0) throw new ApiError(502, 'BAD_RESPONSE', 'The AI returned no slides. Please try again.');
    // Sanitise model output so the client never receives unexpected shapes.
    parsed.themeId = THEME_IDS.includes(parsed.themeId) ? parsed.themeId : 'modern_blue';
    parsed.slides = parsed.slides.slice(0, 40).map((s) => ({
      title: String(s.title ?? '').slice(0, 200),
      content: (Array.isArray(s.content) ? s.content : []).map((c) => String(c).slice(0, 800)).slice(0, 10),
      layout: LAYOUTS.includes(s.layout) ? s.layout : 'centered',
      imagePrompt: String(s.imagePrompt ?? '').slice(0, 500),
    }));
    return { ...parsed, usage: res.usageMetadata ?? null };
  }, { signal }));
}

async function handleImage(body, signal) {
  const prompt = str(body.prompt, 600, 'prompt');
  const isBackground = body.isBackground === true;
  const ai = await getClient();
  return withRetry(async (sig) => {
    const res = await ai.models.generateContent({
      model: IMAGE_MODEL,
      contents: { parts: [{ text: createImagePrompt(prompt, isBackground) }] },
      config: { abortSignal: sig },
    });
    for (const part of res.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData) return { imageData: `data:${part.inlineData.mimeType};base64,${part.inlineData.data}` };
    }
    throw new ApiError(502, 'NO_IMAGE', 'The provider returned no image for this prompt (it may have been filtered). Try rewording it or upload your own image.');
  }, { signal });
}

// ---- HTTP plumbing ----
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json' };
const send = (res, status, obj) => { res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };
const readJson = (req) => new Promise((resolve, reject) => {
  let size = 0, tooBig = false; const chunks = [];
  req.on('data', (c) => {
    if (tooBig) return; // discard the rest so we can still send a proper 413 reply
    size += c.length;
    if (size > 100_000) { tooBig = true; chunks.length = 0; reject(new ApiError(413, 'TOO_LARGE', 'Request body too large (max 100 KB).')); }
    else chunks.push(c);
  });
  req.on('end', () => { if (tooBig) return; try { resolve(JSON.parse(Buffer.concat(chunks).toString() || '{}')); } catch { reject(new ApiError(400, 'BAD_JSON', 'Request body is not valid JSON.')); } });
  req.on('error', reject);
});

export const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname === '/api/status' && req.method === 'GET')
      return send(res, 200, { gemini: { configured: Boolean(process.env.GEMINI_API_KEY), textModel: TEXT_MODEL, imageModel: IMAGE_MODEL } });
    if (url.pathname.startsWith('/api/')) {
      if (req.method !== 'POST') throw new ApiError(405, 'METHOD', 'Use POST.');
      const ctype = req.headers['content-type'] || '';
      if (!ctype.includes('application/json')) throw new ApiError(415, 'BAD_TYPE', 'Content-Type must be application/json.');
      const ctrl = new AbortController();
      res.on('close', () => { if (!res.writableEnded) ctrl.abort(); }); // client cancelled
      const body = await readJson(req);
      if (url.pathname === '/api/plan') return send(res, 200, await handlePlan(body, ctrl.signal));
      if (url.pathname === '/api/image') return send(res, 200, await handleImage(body, ctrl.signal));
      throw new ApiError(404, 'NOT_FOUND', 'Unknown endpoint.');
    }
    // Static files from the production build
    let file = path.join(DIST, path.normalize(url.pathname).replace(/^(\.\.[/\\])+/, ''));
    if (!file.startsWith(DIST) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(DIST, 'index.html');
    if (!fs.existsSync(file)) return send(res, 404, { error: { code: 'NO_BUILD', message: 'Run "npm run build" first, or use "npm run dev".' } });
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  } catch (e) {
    const err = e instanceof ApiError ? e : mapProviderError(e);
    if (!res.headersSent) send(res, err.status, { error: { code: err.code, message: err.message } });
  }
});

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  server.listen(PORT, HOST, () => console.log(`API server on http://${HOST}:${PORT} (Gemini key ${process.env.GEMINI_API_KEY ? 'configured' : 'NOT configured'})`));
}
